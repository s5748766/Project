//StartScreen_Draw 함수 뒤에 넣기

/* --- DeadScreen 전용 LCG 난수 --- */
static uint32_t ds_seed = 0x13572468u;
static inline uint32_t ds_lcg(void){
    ds_seed = ds_seed * 1664525u + 1013904223u;
    return ds_seed;
}

/* --- 작은 가로 대시(‘-’) 찍기: 중심(xc,yc), 길이 len, 두께 th --- */
static inline void PutDashH(int xc, int yc, int len, int th, uint16_t col){
    if (len < 1) len = 1;
    if (th  < 1) th  = 1;
    int x0 = xc - len/2;
    int y0 = yc - th/2;
    if (x0 < 0) { len -= -x0; x0 = 0; }
    if (y0 < 0) { th  -= -y0; y0 = 0; }
    if (x0 + len > LCD_WIDTH)  len = LCD_WIDTH  - x0;
    if (y0 + th  > LCD_HEIGHT) th  = LCD_HEIGHT - y0;
    if (len > 0 && th > 0)
        ILI9341_FillRect(x0, y0, len, th, col);
}

/* ===== 사망 폭발: '-' 대시가 링처럼 퍼지고, 중심부터 서서히 사라짐 ===== */
static void DeadScreen_Draw(void) {
    /* 폭발 중심: 팩맨 현재 픽셀 좌표 */
    const int cx = pacman.x * GRID_SIZE + GRID_SIZE / 2;
    const int cy = pacman.y * GRID_SIZE + GRID_SIZE / 2;
    /* 반경: 화면 전체의 약 90%까지 허용 */
    const int full = (LCD_WIDTH < LCD_HEIGHT ? LCD_WIDTH : LCD_HEIGHT) * 0.9f;

    int roomL = cx, roomR = LCD_WIDTH  - 1 - cx;
    int roomT = cy, roomB = LCD_HEIGHT - 1 - cy;
    int edgeLimited = roomL;
    if (roomR < edgeLimited) edgeLimited = roomR;
    if (roomT < edgeLimited) edgeLimited = roomT;
    if (roomB < edgeLimited) edgeLimited = roomB;

    /* 두 배 정도 넓힌 폭발 반경 */
    const int maxr = (edgeLimited < full ? edgeLimited : (int)full);

    /* 파라미터 */
    const int step_r = 3;          // 반경 증가 속도
    const int frame_delay_ms = 10; // 프레임 간 딜레이

    /* 화면 어둡게 시작 */
    ILI9341_FillRect(0, 0, LCD_WIDTH, LCD_HEIGHT, COLOR_BLACK);

    /* 1) 중심에서 바깥으로: '-' 대시 링을 뿌린다 */
    for (int r = 0; r <= maxr; r += step_r) {
        /* 색상 그라데이션: 노랑 → 오렌지 → 빨강 */
        uint16_t col = (r < (int)(maxr * 0.35f)) ? COLOR_YELLOW :
                       (r < (int)(maxr * 0.70f)) ? COLOR_ORANGE : COLOR_RED;

        /* 링 위 대시 개수(둘레 비례, 하한 10) */
        int count = 8 + (int)((2.f * 3.1415926f * r) / 12.f);
        if (count < 10) count = 10;

        for (int i = 0; i < count; ++i) {
            float base = (2.f * 3.1415926f * i) / (float)count;
            /* 각도/반경에 약간 지터(±1~2° 수준) */
            float jitter = ((int)(ds_lcg() % 61) - 30) * (3.1415926f / 1800.f);
            float a = base + jitter;

            int x = cx + (int)(r * cosf(a));
            int y = cy + (int)(r * sinf(a));

            /* 대시 길이/두께를 살짝 랜덤화 (길이 4~8, 두께 1~2) */
            int len = 4 + (int)(ds_lcg() % 5);       // 4..8
            int th  = 1 + (int)(ds_lcg() & 1);       // 1..2

            /* 가로 대시로 찍기(‘-’ 느낌). 방향은 모두 수평로 통일 */
            if ((unsigned)x < LCD_WIDTH && (unsigned)y < LCD_HEIGHT)
                PutDashH(x, y, len, th, col);
        }

        /* 중심을 조금씩 비워 ‘산산이’ 느낌 */
        if ((r % (step_r * 2)) == 0) {
            int holes = count / 4;
            for (int k = 0; k < holes; ++k) {
                int rx = cx + ((int)ds_lcg() % (r ? r : 1)) - r/2;
                int ry = cy + ((int)ds_lcg() % (r ? r : 1)) - r/2;
                if ((unsigned)rx < LCD_WIDTH && (unsigned)ry < LCD_HEIGHT)
                    ILI9341_DrawPixel(rx, ry, COLOR_BLACK);
            }
        }

        HAL_Delay(frame_delay_ms);
    }

    /* 2) 페이드아웃: 중심에서부터 검정 원을 키워가며 지운다 */
    for (int er = 2; er <= maxr; er += 3) {
        DrawFilledCircle(cx, cy, er, COLOR_BLACK);   // 가운데부터 서서히 사라짐
        HAL_Delay(12);
    }

    /* 3) 잔여 점수 정리(조금의 랜덤 블랙 스플랫) */
    for (int t = 0; t < 3; ++t) {
        int n = 60 + (ds_lcg() % 40);
        for (int j = 0; j < n; ++j) {
            int rx = (int)(ds_lcg() % LCD_WIDTH);
            int ry = (int)(ds_lcg() % LCD_HEIGHT);
            ILI9341_DrawPixel(rx, ry, COLOR_BLACK);
        }
        HAL_Delay(8);
    }
}




		//사망 화면
	    DeadScreen_Draw();