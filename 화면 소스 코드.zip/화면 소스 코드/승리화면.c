static int text_center_x(const char* s,int scale){
    int w = ((int)strlen(s))*6*scale;
    if(w>LCD_WIDTH) w = LCD_WIDTH;
    return (LCD_WIDTH - w)/2;
}

/* ----- LCG 난수 (컨페티/각도 지터용) ----- */
static uint32_t fw_seed = 0x31415927u;
static inline uint32_t fw_rand(void){
    fw_seed = fw_seed * 1664525u + 1013904223u;
    return fw_seed;
}

/* 안전한 사각 점 찍기(2x2 기본) */
static inline void PutDot2(int x, int y, uint16_t c){
    if ((unsigned)x < LCD_WIDTH && (unsigned)y < LCD_HEIGHT) {
        int x0 = (x>0)?(x-1):x, y0 = (y>0)?(y-1):y;
        int w = (x0+2 <= LCD_WIDTH)  ? 2 : (LCD_WIDTH  - x0);
        int h = (y0+2 <= LCD_HEIGHT) ? 2 : (LCD_HEIGHT - y0);
        ILI9341_FillRect(x0, y0, w, h, c);
    }
}

/* 화면 안쪽으로 위치 보정(여유 margin) */
static void clamp_inside(int *x, int *y, int margin){
    if (*x < margin) *x = margin;
    if (*x > (LCD_WIDTH - 1 - margin)) *x = LCD_WIDTH - 1 - margin;
    if (*y < margin) *y = margin;
    if (*y > (LCD_HEIGHT - 1 - margin)) *y = LCD_HEIGHT - 1 - margin;
}






/* ----- 축포: 폭발 → 중심부터 페이드아웃 ----- */
static void Firework_BurstFade(int xc, int yc, int rmax){
    if (rmax < 10) rmax = 10;

    /* 1) 폭발: 링을 늘려가며 점 뿌리기 */
    const int step_r = 3;
    for (int r = 3; r <= rmax; r += step_r) {
        /* 색상: 안쪽 노랑 → 중간 오렌지 → 바깥 흰색 */
        uint16_t col = (r < (int)(rmax * 0.33f)) ? COLOR_YELLOW :
                       (r < (int)(rmax * 0.66f)) ? COLOR_ORANGE : COLOR_WHITE;

        /* 링 위 점 개수(둘레에 비례, 상한 50) */
        int count = 10 + (int)((2.f * 3.1415926f * r) / 12.f);
        if (count > 50) count = 50;

        for (int i = 0; i < count; ++i) {
            float base = (2.f * 3.1415926f * i) / (float)count;
            float jitter = ((int)(fw_rand()%61) - 30) * (3.1415926f/1800.f); // ±~1.7°
            float a = base + jitter;

            int x = xc + (int)(r * cosf(a));
            int y = yc + (int)(r * sinf(a));
            PutDot2(x, y, col);
        }
        HAL_Delay(10);
    }

    /* 2) 페이드: 중심에서부터 검정 원을 키워가며 지우기 */
    for (int er = 2; er <= rmax; er += 3) {
        DrawFilledCircle(xc, yc, er, COLOR_BLACK);  /* 중심부터 서서히 사라짐 */
        HAL_Delay(12);
    }

    /* 3) 가장자리 남은 점 약간 정리(블랙 스플랫) */
    for (int t=0; t<3; ++t){
        int n = 60 + (fw_rand()%40);
        for (int j=0;j<n;++j){
            int rx = (int)(fw_rand()%LCD_WIDTH);
            int ry = (int)(fw_rand()%LCD_HEIGHT);
            ILI9341_DrawPixel(rx, ry, COLOR_BLACK);
        }
        HAL_Delay(8);
    }
}

/* ====== 문자 없이: 팩맨 + 주변 축포(2~3개) ====== */
static void ClearScreen_Draw(void){
    /* 배경 초기화 */
    ILI9341_FillScreen(COLOR_BLACK);
    fw_seed ^= (HAL_GetTick() | 0xA5A55A5Au);

    /* 중앙 팩맨 유지(살짝 입 애니메 2프레임) */
    int pcx = LCD_WIDTH/2;
    int pcy = LCD_HEIGHT/2 + 8;
    int pr  = (LCD_WIDTH < LCD_HEIGHT ? LCD_WIDTH : LCD_HEIGHT) / 6;
    DrawPacman(pcx, pcy, pr, 28.f, COLOR_YELLOW, COLOR_BLACK);
    HAL_Delay(120);
    DrawPacman(pcx, pcy, pr, 8.f,  COLOR_YELLOW, COLOR_BLACK);

    /* 축포 위치 계산: 팩맨 주변 원 위에 2~3개 */
    int fireworks = 2 + (fw_rand()%2);         // 2 또는 3개
    float base_ang = (float)(fw_rand()%360) * 3.1415926f/180.f;
    int ring_r = (int)(pr * 1.8f);             // 팩맨에서 약간 떨어진 반경
    int fr_max = (LCD_WIDTH < LCD_HEIGHT ? LCD_WIDTH : LCD_HEIGHT) / 2;
    int fw_rmax = (int)(fr_max * 0.45f);       // 축포 자체의 최대 반경(화면 절반 미만)

    for (int k=0; k<fireworks; ++k) {
        float a = base_ang + k * (2.f*3.1415926f / fireworks);
        /* 위치 */
        int fx = pcx + (int)(ring_r * cosf(a));
        int fy = pcy + (int)(ring_r * sinf(a));
        clamp_inside(&fx, &fy, fw_rmax + 6);   // 화면 밖으로 나가지 않게 마진 확보

        /* 축포 1개 연출 */
        Firework_BurstFade(fx, fy, fw_rmax);

        /* 팩맨이 가려졌다면 다시 한 번 그려 안정감 부여 */
        DrawPacman(pcx, pcy, pr, 12.f, COLOR_YELLOW, COLOR_BLACK);
    }

    /* 입력 대기 후 복귀 */
    wait_for_any_button_press();
}