/* USER CODE BEGIN 0 */
static int fidx(char c) {
	switch (c) {
	case ' ':
		return 0;
	case 'N':
		return 1;
	case 'A':
		return 2;
	case 'M':
		return 3;
	case 'C':
		return 4;
	case 'P':
		return 5;
	default:
		return 0;
	}
}

/* ===== 좌우+상하 동시 미러 (글자용) ===== */
static void DrawChar5x7_FlipXY(int x, int y, char c, uint16_t fg, uint16_t bg, int s) {
    int i = fidx(c);
    for (int col = 0; col < 5; col++) {
        /* 좌우 반전을 위해 오른쪽 열부터 읽고, */
        uint8_t bits = font5x7[i][4 - col];
        for (int row = 0; row < 7; row++) {
            /* 상하 반전을 위해 아래쪽 행부터 찍는다 */
            uint16_t color = (bits & (1 << (row))) ? fg : bg;  // row를 그대로 쓰면 위아래 뒤집힘
            ILI9341_FillRect(x + col * s, y + row * s, s, s, color);
        }
    }
    /* 글자 간 공백 */
    ILI9341_FillRect(x + 5 * s, y, s, 7 * s, bg);
}

static void DrawText_FlipXY(int x, int y, const char *s, uint16_t fg, uint16_t bg, int scale) {
    int cx = x;
    while (*s) {
        DrawChar5x7_FlipXY(cx, y, *s++, fg, bg, scale);
        cx += 6 * scale;
    }
}

static void StartScreen_Draw(void) {
	/* 반전 ON */
	g_mirror_xy = 1;

	ILI9341_FillScreen(COLOR_BLACK);

	const float W_REF = 360.0f;
	const float H_REF = 210.0f;

	float s = (float) LCD_WIDTH / W_REF;
	int scene_w = (int) (W_REF * s + 0.5f);
	int scene_h = (int) (H_REF * s + 0.5f);
	int x0 = (LCD_WIDTH - scene_w) / 2;
	int y0 = (LCD_HEIGHT - scene_h) / 2;

	int stroke = (int) (3 * s);
	if (stroke < 2)
		stroke = 2;

	/* 미로 프레임 */
	DrawRoundRect(x0 + (20 * s), y0 + (15 * s), (70 * s), (70 * s), (18 * s),
			stroke, COLOR_BLUE);
	DrawRoundRect(x0 + (270 * s), y0 + (135 * s), (70 * s), (70 * s), (18 * s),
			stroke, COLOR_BLUE);
	DrawRoundRect(x0 + (328 * s), y0 + (20 * s), (28 * s), (110 * s), (14 * s),
			stroke, COLOR_BLUE);
	DrawRoundRect(x0 + (20 * s), y0 + (120 * s), (28 * s), (110 * s), (14 * s),
			stroke, COLOR_BLUE);
	DrawRoundRect(x0 + (120 * s), y0 + (38 * s), (85 * s), (22 * s), (11 * s),
			stroke, COLOR_BLUE);
	DrawRoundRect(x0 + (215 * s), y0 + (38 * s), (85 * s), (22 * s), (11 * s),
			stroke, COLOR_BLUE);

	/* 과일 아이콘 */
	DrawFilledCircle(x0 + (210 * s), y0 + (30 * s), (5 * s), COLOR_RED);
	DrawFilledCircle(x0 + (165 * s), y0 + (30 * s), (5 * s), COLOR_RED);
	DrawFilledCircle(x0 + (58 * s), y0 + (172 * s), (6 * s), COLOR_RED);

	/* 중앙 로고 */
	int logo_scale = (int) (5 * s);
	if (logo_scale < 2)
		logo_scale = 2;
	int text_y = y0 + (80 * s);
	DrawText_FlipXY(x0 + (110 * s), text_y, "PAC", COLOR_YELLOW, COLOR_BLACK,
			logo_scale);
	DrawText_FlipXY(x0 + (110 * s) + 3 * (6 * logo_scale) + (8 * s), text_y, "MAN",
			COLOR_YELLOW, COLOR_BLACK, logo_scale);

	/* 하단 도트 & 팩맨 */
	int dot_r = (int) (3 * s);
	if (dot_r < 2)
		dot_r = 2;
	int big_r = (int) (7 * s);
	int base_y = y0 + (140 * s);
	int base_x = x0 + (100 * s);

	for (int i = 0; i < 7; i++)
		DrawFilledCircle(base_x + i * (12 * s), base_y, dot_r, COLOR_ORANGE);
	for (int i = 1; i < 8; i++)
		DrawFilledCircle(base_x, base_y + i * (12 * s), dot_r, COLOR_ORANGE);

	DrawFilledCircle(base_x + (8 * 12 * s), base_y, big_r, COLOR_ORANGE);
	DrawFilledCircle(base_x + (4 * 12 * s), base_y - (12 * s), (int) (5 * s),
			COLOR_ORANGE);

	for (int i = 1; i <= 10; i++)
		DrawFilledCircle(base_x + (8 * 12 * s) + i * (11 * s),
				base_y + (12 * s), dot_r, COLOR_ORANGE);

	/* 원본은 오른쪽 끝 팩맨(왼쪽 바라보는 형태로 그렸음) — 전체 반전이 적용되어 최종적으로 상하/좌우 뒤집혀 보임 */
	DrawPacman_FlipX(base_x + (8 * 12 * s) + (11 * 11 * s), base_y + (12 * s),
			(int) (10 * s), 45.f, COLOR_YELLOW, COLOR_BLACK);

	/* 유령들 */
	DrawGhost(x0 + (75 * s), y0 + (120 * s), (24 * s), (18 * s), COLOR_CYAN,
			COLOR_BLACK);
	DrawGhost(x0 + (180 * s), y0 + (185 * s), (24 * s), (18 * s), COLOR_RED,
			COLOR_BLACK);
	DrawGhost(x0 + (315 * s), y0 + (115 * s), (24 * s), (18 * s), COLOR_PINK,
			COLOR_BLACK);

	/* 반전 OFF (이후 화면에는 영향 없음) */
	g_mirror_xy = 0;
}